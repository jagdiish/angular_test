var myApp = angular.module('myApp', ['ui.router']);

myApp.config(['$httpProvider', '$stateProvider', '$urlRouterProvider',
	function ($httpProvider, $stateProvider, $urlRouterProvider) {

		$stateProvider
			.state('home', {
				url: '/home',
				parent: 'menu',
				templateUrl: 'home.html',
			})
		
		
		.state('inner-pg-a', {
              url: 'inner-pg-a/inner-pg-a-1', 
            templateUrl: 'pages/inner-pg-a/inner-pg-a-1.html',
        	
			})
		
		
		

		.state('menu', {
			templateUrl: 'menu.html',
		})

		.state('temp_cont', {
			url: '/temp_cont',
			parent: 'menu',
			template: '<div><h4>I am a directly appended template content!</h4></div>',
		})

		.state('page-a', {
			url: '/page-a',
			parent: 'menu',
			templateUrl: 'pages/page-a.html',
		})

		.state('page-b', {
			url: '/page-b',
			parent: 'menu',
			templateUrl: 'pages/page-b.html',
		})
		
//		Inner Pages
		
		/*.state('pages/inner-pg-a', {
			url: 'inner-pg-a-1',
			parent: 'menu',
			templateUrl: 'inner-pg-a-1.html',
		})
		
		.state('pages/inner-pg-a', {
			url: 'inner-pg-a-2',
			parent: 'menu',
			templateUrl: 'inner-pg-a-2.html',
		})*/
		
//		Inner Pages End
		
		.state('login', {
			url: '/login',
			parent: 'menu',
			templateUrl: 'login.html',
		});
		
		

		//$urlRouterProvider.otherwise('/home');
	}
]);
